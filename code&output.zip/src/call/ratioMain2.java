package call;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.Iterator;

public class ratioMain2 {

	public static class ratioMapper extends Mapper<Object, Text, Text, Text> {

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

			String l = value.toString();
			String line[] = l.split("\t");
			String calling_nbr = line[1];
			String start_time = line[9];
			String end_time = line[10];
			String raw_dur = line[11];

			String[] start = start_time.split(":");
			int h = Integer.parseInt(start[0]);
			int m = Integer.parseInt(start[1]);
			int s = Integer.parseInt(start[2]);
			long total_start = h * 3600 + m * 60 + s;
			String[] end = end_time.split(":");
			int h_end = Integer.parseInt(end[0]);
			int m_end = Integer.parseInt(end[1]);
			int s_end = Integer.parseInt(end[2]);
			long total_end = h_end * 3600 + m_end * 60 + s_end;
			int dur_end = Integer.parseInt(raw_dur);

			if (dur_end == 0) {
				if (total_end != 0) {
					dur_end = (int) (total_end - total_start);
					raw_dur = String.valueOf(dur_end);
					context.write(new Text(calling_nbr), new Text(start_time + ',' + end_time + ',' + raw_dur));
				}
			} else if (total_end == 0) {
				total_end = total_start + dur_end;
				if (total_end > 24 * 3600) {
					total_end = total_end - 24 * 3600;
				}
				h_end = (int) Math.floor(total_end / 3600);
				total_end = total_end - h_end * 3600;
				m_end = (int) Math.floor(total_end / 60);
				total_end = total_end - m_end * 60;
				s_end = (int) total_end;
				StringBuffer str = new StringBuffer();
				str.append(String.valueOf(h_end)).append(":").append(String.valueOf(m_end)).append(":")
						.append(String.valueOf(s_end));
				end_time = str.toString();
				context.write(new Text(calling_nbr), new Text(start_time + ',' + end_time + ',' + raw_dur));
			} else {
				context.write(new Text(calling_nbr), new Text(start_time + ',' + end_time + ',' + raw_dur));
			}
		}
	}

	public static class ratioReducer extends Reducer<Text, Text, Text, Text> {

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

			double periods[] = new double[8];
			double sum = 0;

			Iterator<Text> it = values.iterator();
			while (it.hasNext()) {
				String l = it.next().toString();
				String line[] = l.split(",");
				String start_time = line[0];
				String end_time = line[1];
				double raw_dur = Integer.parseInt(line[2]);
				sum = sum + 1;

				int h = Integer.parseInt(start_time.split(":")[0]);
				int m = Integer.parseInt(start_time.split(":")[1]);
				int s = Integer.parseInt(start_time.split(":")[2]);
				int h_end = Integer.parseInt(end_time.split(":")[0]);
				int m_end = Integer.parseInt(end_time.split(":")[1]);
				int s_end = Integer.parseInt(end_time.split(":")[2]);
				int stay_start;
				int stay_end;
				int start = (int) Math.floor(h / 3);
				int end = (int) Math.floor(h_end / 3);

				if (start == end) {
					periods[start] = periods[start] + 1;
				} else {
					stay_start = (start + 1) * 3 * 60 * 60 - h * 60 * 60 - m * 60 - s;
					stay_end = h_end * 60 * 60 + m_end * 60 + s_end - end * 3 * 60 * 60;
					if (stay_start >= stay_end) {
						periods[start] = periods[start] + 1;
					} else {
						periods[end] = periods[end] + 1;
					}
				}
			}
		

		String count[] = new String[8];for(
		int a = 0;a<=7;a++)
		{
			count[a] = String.valueOf(periods[a] / sum);
		}context.write(key,new Text(count[0]+','+count[1]+','+count[2]+','+count[3]+','+count[4]+','+count[5]+','+count[6]+','+count[7]));
	}

	}

	public static void main(String[] args) throws Exception {

		UserGroupInformation ugi = UserGroupInformation.createRemoteUser("root");

		ugi.doAs(new PrivilegedExceptionAction<Void>() {

			public Void run() throws Exception {

				Configuration conf = new Configuration();
				String[] otherArgs = new String[] { "input/tb_call_201202_random.txt", "output5" };
				Job job = Job.getInstance(conf, "ratioMain");
				job.setJarByClass(ratioMain2.class);
				job.setJobName("ratio");

				FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
				FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));

				job.setMapperClass(ratioMapper.class);
				job.setReducerClass(ratioReducer.class);
				job.setOutputKeyClass(Text.class);
				job.setOutputValueClass(Text.class);
				System.exit(job.waitForCompletion(true) ? 0 : 1);
				return null;
			}
		});
	}
}
