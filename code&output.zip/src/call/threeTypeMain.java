package call;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.Iterator;

public class threeTypeMain {

	public static class typeMapper extends Mapper<Object, Text, Text, IntWritable> {

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			String l = value.toString();
			String line[] = l.split("\t");
			int called_optr = Integer.parseInt(line[4]);
			String call_type = line[12];
			Text word = new Text(call_type);
			IntWritable one = new IntWritable(called_optr);
			context.write(word, one);
		}
	}

	public static class typeReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {

		public void reduce(Text text, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			Iterator<IntWritable> it = values.iterator();
			double telecom = 0;
			double mobilecom = 0;
			double unicom = 0;
			double sum = 0;

			while (it.hasNext()) {
				sum++;
				int called_optr = it.next().get();
				if (called_optr == 1) {
					telecom++;
				} else if (called_optr == 2) {
					mobilecom++;
				} else if (called_optr == 3) {
					unicom++;
				}
			}
			double telecomCount = telecom / sum;
			double mobilecomCount = mobilecom / sum;
			double unicomCount = unicom / sum;

			context.write(text, new DoubleWritable(telecomCount)); // 电信
			context.write(text, new DoubleWritable(mobilecomCount)); // 移动
			context.write(text, new DoubleWritable(unicomCount)); // 联通
		}

	}

	public static void main(String[] args) throws Exception {

		UserGroupInformation ugi = UserGroupInformation.createRemoteUser("root");

		ugi.doAs(new PrivilegedExceptionAction<Void>() {

			public Void run() throws Exception {

				Configuration conf = new Configuration();
				String[] otherArgs = new String[] { "input/tb_call_201202_random.txt", "output2" };

				Job job = Job.getInstance(conf, "threeTypeMain");
				job.setJarByClass(threeTypeMain.class);
				job.setJobName("threeType");

				FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
				FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));

				job.setMapperClass(threeTypeMain.typeMapper.class);
				job.setReducerClass(threeTypeMain.typeReducer.class);
				job.setOutputKeyClass(Text.class);
				job.setOutputValueClass(IntWritable.class);
				System.exit(job.waitForCompletion(true) ? 0 : 1);

				return null;
			}
		});
	}
}
