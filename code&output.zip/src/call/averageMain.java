package call;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.Iterator;

public class averageMain {

	public static class averageMapper extends Mapper<Object, Text, Text, IntWritable> {

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

			String l = value.toString();
			String line[] = l.split("\t");
			int day_id = Integer.parseInt(line[0]);
			String calling_nbr = line[1];
			Text word = new Text(calling_nbr);
			IntWritable one = new IntWritable(day_id);
			context.write(word, one);
		}
	}

	public static class averageReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {

		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {

			double sum = 1;
			double num = 1;
			Iterator<IntWritable> it = values.iterator();
			int day_id = it.next().get();

			while (it.hasNext()) {
				sum += 1;
				int day_id_next = it.next().get();
				if (day_id != day_id_next) {
					num += 1;
					day_id = day_id_next;
				}
			}
			sum = sum / num;
			DoubleWritable one = new DoubleWritable(sum);
			context.write(key, one);
		}
	}

	public static void main(String[] args) throws Exception {

		UserGroupInformation ugi = UserGroupInformation.createRemoteUser("root");

		ugi.doAs(new PrivilegedExceptionAction<Void>() {

			public Void run() throws Exception {

				Configuration conf = new Configuration();
				String[] otherArgs = new String[] { "input/tb_call_201202_random.txt", "output1" };

				Job job = Job.getInstance(conf, "averageMain");
				job.setJarByClass(averageMain.class);
				job.setJobName("avgerage");

				FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
				FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));

				job.setMapperClass(averageMain.averageMapper.class);
				job.setReducerClass(averageMain.averageReducer.class);
				job.setOutputKeyClass(Text.class);
				job.setOutputValueClass(IntWritable.class);
				System.exit(job.waitForCompletion(true) ? 0 : 1);
				return null;
			}
		});
	}
}
